# VaultKeep Android App - Cloud Build Version

This project is designed for users who cannot run Android Studio locally. You can build the APK in the cloud with GitHub Actions using only a browser.

## What this version includes

- Native Android Java app, no WebView wrapper.
- Package: `com.vaultkeep.app`.
- `minSdkVersion`: 23.
- `targetSdkVersion`: 35.
- Master-password setup and unlock flow.
- Local encrypted vault storage using PBKDF2-HMAC-SHA256 and AES-GCM.
- Add, view, edit, delete password entries.
- Password generator using `SecureRandom`.
- Search, simple categories, security dashboard, and settings screens.
- No internet permission.
- Backup disabled in the Android manifest/data extraction rules.

## Build without Android Studio

1. Create or open a GitHub account.
2. Create a new empty repository, for example `vaultkeep`.
3. Upload all files from this folder to the repository.
4. Open the repository's **Actions** tab.
5. Select **Build VaultKeep APK**.
6. Press **Run workflow**.
7. When it finishes, open the completed workflow run.
8. Download the artifact named **VaultKeep-debug-apk**.
9. Unzip it. Inside is `app-debug.apk`.
10. Copy `app-debug.apk` to your Android phone and install it.

## Important security warning

This is a functional encrypted MVP, not an audited production password manager. Do not store important real passwords until the app has been reviewed by an Android security developer and upgraded with Android Keystore, native BiometricPrompt unlock, AutofillService, release signing, and a professional security audit.
