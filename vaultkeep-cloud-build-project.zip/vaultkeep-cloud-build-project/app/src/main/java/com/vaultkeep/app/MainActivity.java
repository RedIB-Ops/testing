package com.vaultkeep.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;
import android.text.InputType;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final String PREF = "vaultkeep_secure_store";
    private static final String K_SALT = "salt";
    private static final String K_VERIFIER = "verifier";
    private static final String K_VAULT = "vault";
    private static final int BLUE = Color.rgb(20,123,255);
    private static final int TEAL = Color.rgb(76,217,196);
    private static final int DARK = Color.rgb(9,24,55);
    private static final int MUTED = Color.rgb(105,119,143);
    private static final int BG = Color.rgb(250,252,255);
    private static final int CARD = Color.WHITE;

    private final SecureRandom random = new SecureRandom();
    private SharedPreferences prefs;
    private SecretKeySpec vaultKey;
    private String currentFilter = "All";
    private final ArrayList<Credential> credentials = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 23) w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (!prefs.contains(K_SALT) || !prefs.contains(K_VERIFIER)) showSetup(); else showUnlock();
    }

    private void showSetup() {
        LinearLayout box = base("VaultKeep", "Create your encrypted vault");
        addText(box, "Set a strong master password. VaultKeep will encrypt your saved passwords locally on this device.", 16, MUTED, false);
        EditText pass = field("Master password", true);
        EditText confirm = field("Confirm master password", true);
        box.addView(pass); box.addView(confirm);
        TextView btn = primaryButton("Create vault");
        btn.setOnClickListener(v -> {
            String p = pass.getText().toString();
            if (p.length() < 8) { toast("Use at least 8 characters"); return; }
            if (!p.equals(confirm.getText().toString())) { toast("Passwords do not match"); return; }
            try {
                byte[] salt = bytes(16);
                vaultKey = deriveKey(p, salt);
                prefs.edit().putString(K_SALT, b64(salt)).putString(K_VERIFIER, sha256b64(vaultKey.getEncoded())).apply();
                credentials.clear();
                saveVault();
                showHome();
            } catch (Exception e) { showFatal(e); }
        });
        box.addView(btn);
        setContentView(wrap(box));
    }

    private void showUnlock() {
        LinearLayout box = base("VaultKeep", "Unlock your vault");
        TextView icon = addText(box, "🔐", 48, BLUE, false);
        icon.setGravity(Gravity.CENTER_HORIZONTAL);
        addText(box, "Enter your master password to access your encrypted data.", 16, MUTED, false);
        EditText pass = field("Master password", true);
        box.addView(pass);
        TextView btn = primaryButton("Unlock");
        btn.setOnClickListener(v -> {
            try {
                byte[] salt = unb64(prefs.getString(K_SALT, ""));
                SecretKeySpec key = deriveKey(pass.getText().toString(), salt);
                if (!sha256b64(key.getEncoded()).equals(prefs.getString(K_VERIFIER, ""))) { toast("Wrong master password"); return; }
                vaultKey = key;
                loadVault();
                showHome();
            } catch (Exception e) { showFatal(e); }
        });
        box.addView(btn);
        TextView reset = link("Reset local vault");
        reset.setOnClickListener(v -> confirmReset());
        box.addView(reset);
        setContentView(wrap(box));
    }

    private void showHome() {
        LinearLayout box = base("VaultKeep", "Good morning, Phin 👋");
        EditText search = field("Search vault", false);
        box.addView(search);
        box.addView(statsCard());
        LinearLayout chips = new LinearLayout(this); chips.setOrientation(LinearLayout.HORIZONTAL); chips.setGravity(Gravity.LEFT); chips.setPadding(0,8,0,8);
        String[] cats = {"All","Social","Finance","Work","Shopping"};
        for (String c : cats) chips.addView(chip(c, c.equals(currentFilter), () -> { currentFilter = c; showHome(); }));
        box.addView(chips);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); box.addView(list);
        Runnable render = () -> renderList(list, search.getText().toString());
        search.setOnEditorActionListener((v, actionId, event) -> { render.run(); return false; });
        search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ render.run(); } public void afterTextChanged(android.text.Editable e){} });
        render.run();
        box.addView(bottomNav("Vault"));
        setContentView(wrap(box));
    }

    private void renderList(LinearLayout list, String q) {
        list.removeAllViews();
        String s = q == null ? "" : q.toLowerCase();
        for (Credential c : credentials) {
            if (!currentFilter.equals("All") && !currentFilter.equals(c.category)) continue;
            if (s.length() > 0 && !(c.service.toLowerCase().contains(s) || c.username.toLowerCase().contains(s))) continue;
            list.addView(credentialCard(c));
        }
        if (credentials.isEmpty()) {
            addText(list, "No passwords yet", 20, DARK, true);
            addText(list, "Tap Add to save your first login.", 15, MUTED, false);
        }
        TextView add = primaryButton("+ Add new password");
        add.setOnClickListener(v -> showEdit(null));
        list.addView(add);
    }

    private View credentialCard(Credential c) {
        LinearLayout card = card();
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = circle(c.service.length() > 0 ? c.service.substring(0,1).toUpperCase() : "?");
        row.addView(logo);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(14),0,0,0);
        col.addView(text(c.service, 18, DARK, true));
        col.addView(text(c.username, 14, MUTED, false));
        col.addView(text("••••••••••", 18, Color.BLACK, false));
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView badge = pill(strengthLabel(c.password)); row.addView(badge);
        card.addView(row);
        card.setOnClickListener(v -> showDetail(c));
        return card;
    }

    private View statsCard() {
        LinearLayout card = cardGradient();
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER);
        row.addView(stat("🔒", String.valueOf(credentials.size()), "Total passwords"));
        row.addView(stat("⚠️", String.valueOf(countWeak()), "Weak passwords"));
        row.addView(stat("🔄", "Now", "Last sync"));
        card.addView(row);
        return card;
    }

    private View stat(String icon, String num, String label) {
        LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); v.setGravity(Gravity.CENTER); v.setPadding(dp(8),dp(8),dp(8),dp(8));
        v.addView(text(icon, 22, Color.WHITE, false));
        v.addView(text(num, 24, Color.WHITE, true));
        v.addView(text(label, 12, Color.WHITE, false));
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return v;
    }

    private void showDetail(Credential c) {
        LinearLayout box = base("Account details", c.service);
        box.addView(detailRow("Username", c.username, () -> copy(c.username)));
        box.addView(detailRow("Password", "••••••••••", () -> copy(c.password)));
        box.addView(detailRow("Website", c.url.length() == 0 ? "No website" : c.url, () -> copy(c.url)));
        box.addView(detailRow("Category", c.category, null));
        box.addView(detailRow("Notes", c.notes.length() == 0 ? "No notes" : c.notes, null));
        addText(box, "Security", 22, DARK, true);
        box.addView(detailRow("Strength", strengthLabel(c.password), null));
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView edit = secondaryButton("Edit"); edit.setOnClickListener(v -> showEdit(c));
        TextView del = secondaryButton("Delete"); del.setOnClickListener(v -> { credentials.remove(c); try { saveVault(); showHome(); } catch(Exception e){ showFatal(e); } });
        TextView back = secondaryButton("Back"); back.setOnClickListener(v -> showHome());
        actions.addView(back, new LinearLayout.LayoutParams(0, dp(54), 1));
        actions.addView(edit, new LinearLayout.LayoutParams(0, dp(54), 1));
        actions.addView(del, new LinearLayout.LayoutParams(0, dp(54), 1));
        box.addView(actions);
        setContentView(wrap(box));
    }

    private View detailRow(String a, String b, Runnable click) {
        LinearLayout card = card();
        card.addView(text(a, 13, MUTED, false));
        TextView val = text(b, 17, DARK, false); card.addView(val);
        if (click != null) { card.setOnClickListener(v -> click.run()); val.setText(b + "    Copy"); }
        return card;
    }

    private void showEdit(Credential existing) {
        boolean isEdit = existing != null;
        LinearLayout box = base(isEdit ? "Edit password" : "Add new password", isEdit ? existing.service : "Save a new login");
        EditText service = field("App or website name", false);
        EditText username = field("Username / Email", false);
        EditText password = field("Password", false);
        EditText url = field("Website URL", false);
        EditText category = field("Category: Social, Finance, Work, Shopping", false);
        EditText notes = field("Notes", false);
        if (isEdit) {
            service.setText(existing.service); username.setText(existing.username); password.setText(existing.password); url.setText(existing.url); category.setText(existing.category); notes.setText(existing.notes);
        }
        box.addView(service); box.addView(username); box.addView(password);
        TextView gen = secondaryButton("Generate strong password"); gen.setOnClickListener(v -> password.setText(generatePassword(20))); box.addView(gen);
        box.addView(url); box.addView(category); box.addView(notes);
        TextView save = primaryButton(isEdit ? "Save changes" : "Save password");
        save.setOnClickListener(v -> {
            if (service.getText().toString().trim().length() == 0 || password.getText().toString().length() == 0) { toast("Service and password are required"); return; }
            Credential c = isEdit ? existing : new Credential();
            if (!isEdit) { c.id = String.valueOf(System.currentTimeMillis()); credentials.add(c); }
            c.service = service.getText().toString().trim(); c.username = username.getText().toString().trim(); c.password = password.getText().toString(); c.url = url.getText().toString().trim();
            String cat = category.getText().toString().trim(); c.category = cat.length() == 0 ? "Work" : cat; c.notes = notes.getText().toString(); c.updated = System.currentTimeMillis();
            try { saveVault(); showHome(); } catch(Exception e){ showFatal(e); }
        });
        box.addView(save);
        TextView cancel = link("Cancel"); cancel.setOnClickListener(v -> showHome()); box.addView(cancel);
        setContentView(wrap(box));
    }

    private void showGenerator() {
        LinearLayout box = base("Password Generator", "Create strong, unique passwords");
        TextView generated = text(generatePassword(20), 25, DARK, true);
        LinearLayout card = card(); card.addView(text("Generated Password", 14, MUTED, false)); card.addView(generated); card.addView(text("Very Strong", 17, Color.rgb(25,176,94), true)); box.addView(card);
        TextView regen = secondaryButton("Regenerate"); regen.setOnClickListener(v -> generated.setText(generatePassword(20))); box.addView(regen);
        TextView copy = primaryButton("Copy password"); copy.setOnClickListener(v -> copy(generated.getText().toString())); box.addView(copy);
        box.addView(bottomNav("Generator"));
        setContentView(wrap(box));
    }

    private void showSecurity() {
        LinearLayout box = base("Security Dashboard", "Your security at a glance");
        LinearLayout score = cardGradient();
        int weak = countWeak(), reused = countReused();
        int total = credentials.size();
        int points = Math.max(0, 100 - weak * 10 - reused * 8);
        score.addView(text(String.valueOf(points), 46, Color.WHITE, true));
        score.addView(text(points >= 80 ? "Good" : points >= 60 ? "Needs attention" : "Risky", 20, Color.WHITE, true));
        score.addView(text("Weak: " + weak + "   Reused: " + reused + "   Total: " + total, 15, Color.WHITE, false));
        box.addView(score);
        addText(box, "Recommendations", 22, DARK, true);
        box.addView(detailRow("Change weak passwords", weak + " accounts need stronger passwords", null));
        box.addView(detailRow("Avoid password reuse", reused + " repeated passwords found", null));
        box.addView(detailRow("Use 2FA", "Enable 2-step verification on important accounts", null));
        box.addView(bottomNav("Security"));
        setContentView(wrap(box));
    }

    private void showSettings() {
        LinearLayout box = base("Settings", "Phin Sareth");
        box.addView(detailRow("Vault status", credentials.size() + " encrypted items saved locally", null));
        box.addView(detailRow("Auto-lock", "Locks when the app is closed", null));
        box.addView(detailRow("Backup", "Export encrypted JSON backup from source version", null));
        TextView lock = primaryButton("Lock vault"); lock.setOnClickListener(v -> { vaultKey = null; credentials.clear(); showUnlock(); }); box.addView(lock);
        TextView reset = secondaryButton("Reset local vault"); reset.setOnClickListener(v -> confirmReset()); box.addView(reset);
        box.addView(bottomNav("Settings"));
        setContentView(wrap(box));
    }

    private View bottomNav(String active) {
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(0,dp(20),0,dp(10));
        String[] items = {"Vault","Generator","Security","Settings"};
        for (String item : items) {
            TextView b = text((item.equals(active) ? "● " : "○ ") + item, 14, item.equals(active) ? BLUE : MUTED, true);
            b.setGravity(Gravity.CENTER); b.setOnClickListener(v -> { String t = item; if(t.equals("Vault")) showHome(); else if(t.equals("Generator")) showGenerator(); else if(t.equals("Security")) showSecurity(); else showSettings(); });
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(54), 1));
        }
        return nav;
    }

    private LinearLayout base(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(22), dp(26), dp(22), dp(24)); box.setBackgroundColor(BG);
        TextView brand = text("🛡️ VaultKeep", 22, BLUE, true); box.addView(brand);
        addText(box, title, 30, DARK, true);
        if (subtitle != null && subtitle.length() > 0) addText(box, subtitle, 16, MUTED, false);
        return box;
    }

    private ScrollView wrap(LinearLayout box) { ScrollView s = new ScrollView(this); s.setFillViewport(true); s.setBackgroundColor(BG); s.addView(box); return s; }
    private TextView addText(LinearLayout box, String t, int sp, int color, boolean bold) { TextView tv = text(t, sp, color, bold); box.addView(tv); return tv; }
    private TextView text(String t, int sp, int color, boolean bold) { TextView tv = new TextView(this); tv.setText(t); tv.setTextSize(sp); tv.setTextColor(color); tv.setPadding(0, dp(6), 0, dp(6)); if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return tv; }
    private EditText field(String hint, boolean pass) { EditText e = new EditText(this); e.setHint(hint); e.setTextColor(DARK); e.setHintTextColor(Color.rgb(150,160,178)); e.setTextSize(16); e.setSingleLine(false); e.setMinLines(1); e.setPadding(dp(18),0,dp(18),0); if (pass) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); GradientDrawable gd = round(CARD, dp(18)); gd.setStroke(dp(1), Color.rgb(228,234,244)); e.setBackground(gd); e.setLayoutParams(margins(-1, dp(58), 0, dp(10))); return e; }
    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(18), dp(14), dp(18), dp(14)); c.setBackground(round(CARD, dp(18))); c.setLayoutParams(margins(-1, -2, 0, dp(12))); if (Build.VERSION.SDK_INT >= 21) c.setElevation(dp(2)); return c; }
    private LinearLayout cardGradient() { LinearLayout c = card(); GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BLUE, TEAL}); g.setCornerRadius(dp(20)); c.setBackground(g); return c; }
    private TextView primaryButton(String label) { TextView b = text(label, 17, Color.WHITE, true); b.setGravity(Gravity.CENTER); GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BLUE, TEAL}); gd.setCornerRadius(dp(16)); b.setBackground(gd); b.setLayoutParams(margins(-1, dp(56), 0, dp(12))); return b; }
    private TextView secondaryButton(String label) { TextView b = text(label, 16, BLUE, true); b.setGravity(Gravity.CENTER); GradientDrawable gd = round(Color.WHITE, dp(16)); gd.setStroke(dp(1), Color.rgb(205,222,249)); b.setBackground(gd); b.setLayoutParams(margins(-1, dp(54), 0, dp(10))); return b; }
    private TextView link(String label) { TextView v = text(label, 15, BLUE, true); v.setGravity(Gravity.CENTER); return v; }
    private TextView circle(String label) { TextView t = text(label, 24, Color.WHITE, true); t.setGravity(Gravity.CENTER); t.setBackground(round(BLUE, dp(18))); t.setLayoutParams(new LinearLayout.LayoutParams(dp(54), dp(54))); return t; }
    private TextView pill(String label) { int c = label.equals("Strong") ? Color.rgb(25,176,94) : Color.rgb(242,145,35); TextView p = text(label, 13, c, true); p.setGravity(Gravity.CENTER); p.setBackground(round(Color.argb(28, Color.red(c), Color.green(c), Color.blue(c)), dp(14))); p.setPadding(dp(10), dp(4), dp(10), dp(4)); return p; }
    private View chip(String label, boolean active, Runnable click) { TextView c = text(label, 14, active ? Color.WHITE : DARK, true); c.setGravity(Gravity.CENTER); c.setBackground(round(active ? BLUE : Color.WHITE, dp(14))); c.setPadding(dp(12),0,dp(12),0); c.setOnClickListener(v -> click.run()); c.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(42))); return c; }
    private GradientDrawable round(int color, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    private LinearLayout.LayoutParams margins(int w, int h, int top, int bottom) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h); lp.setMargins(0, top, 0, bottom); return lp; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void loadVault() throws Exception {
        credentials.clear();
        String enc = prefs.getString(K_VAULT, "");
        if (enc.length() == 0) return;
        String json = decrypt(enc, vaultKey);
        JSONArray arr = new JSONArray(json);
        for (int i=0;i<arr.length();i++) credentials.add(Credential.from(arr.getJSONObject(i)));
    }
    private void saveVault() throws Exception {
        JSONArray arr = new JSONArray();
        for (Credential c : credentials) arr.put(c.toJson());
        prefs.edit().putString(K_VAULT, encrypt(arr.toString(), vaultKey)).apply();
    }
    private SecretKeySpec deriveKey(String pass, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(pass.toCharArray(), salt, 150000, 256);
        return new SecretKeySpec(f.generateSecret(spec).getEncoded(), "AES");
    }
    private String encrypt(String plain, SecretKeySpec key) throws Exception { byte[] iv=bytes(12); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key,new GCMParameterSpec(128,iv)); byte[] out=c.doFinal(plain.getBytes("UTF-8")); byte[] pack=new byte[iv.length+out.length]; System.arraycopy(iv,0,pack,0,iv.length); System.arraycopy(out,0,pack,iv.length,out.length); return b64(pack); }
    private String decrypt(String data, SecretKeySpec key) throws Exception { byte[] pack=unb64(data); byte[] iv=new byte[12]; byte[] enc=new byte[pack.length-12]; System.arraycopy(pack,0,iv,0,12); System.arraycopy(pack,12,enc,0,enc.length); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv)); return new String(c.doFinal(enc),"UTF-8"); }
    private byte[] bytes(int n) { byte[] b=new byte[n]; random.nextBytes(b); return b; }
    private String b64(byte[] b) { return Base64.encodeToString(b, Base64.NO_WRAP); }
    private byte[] unb64(String s) { return Base64.decode(s, Base64.NO_WRAP); }
    private String sha256b64(byte[] b) throws Exception { MessageDigest md=MessageDigest.getInstance("SHA-256"); return b64(md.digest(b)); }
    private String generatePassword(int n) { String chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*?"; StringBuilder sb=new StringBuilder(); for(int i=0;i<n;i++) sb.append(chars.charAt(random.nextInt(chars.length()))); return sb.toString(); }
    private int countWeak() { int x=0; for(Credential c:credentials) if(!strengthLabel(c.password).equals("Strong")) x++; return x; }
    private int countReused() { Set<String> seen=new HashSet<>(), dup=new HashSet<>(); for(Credential c:credentials) if(!seen.add(c.password)) dup.add(c.password); return dup.size(); }
    private String strengthLabel(String p) { if(p==null) return "Weak"; int score=0; if(p.length()>=12) score++; if(p.matches(".*[A-Z].*")) score++; if(p.matches(".*[0-9].*")) score++; if(p.matches(".*[^A-Za-z0-9].*")) score++; return score>=3 ? "Strong" : "Weak"; }
    private void copy(String s) { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("VaultKeep", s)); toast("Copied"); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void showFatal(Exception e) { Toast.makeText(this, "Error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show(); }
    private void confirmReset() { prefs.edit().clear().apply(); vaultKey=null; credentials.clear(); showSetup(); }

    static class Credential {
        String id="", service="", username="", password="", url="", category="Work", notes=""; long updated=System.currentTimeMillis();
        JSONObject toJson() throws Exception { JSONObject o=new JSONObject(); o.put("id",id); o.put("service",service); o.put("username",username); o.put("password",password); o.put("url",url); o.put("category",category); o.put("notes",notes); o.put("updated",updated); return o; }
        static Credential from(JSONObject o) { Credential c=new Credential(); c.id=o.optString("id"); c.service=o.optString("service"); c.username=o.optString("username"); c.password=o.optString("password"); c.url=o.optString("url"); c.category=o.optString("category","Work"); c.notes=o.optString("notes"); c.updated=o.optLong("updated",System.currentTimeMillis()); return c; }
    }
}
